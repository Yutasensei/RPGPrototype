# RPG Prototype Android 0.1

Android prototype for the 2D vertical RPG concept.

Features:
- 9:16 portrait target
- Touch joystick
- Voxel-inspired player
- Forest resource nodes
- Farm wood and stone
- Cave mode
- Monster and attack button
- Gold reward
- HUD

Build with Android Studio / Gradle:
`./gradlew assembleDebug`

The resulting debug APK is:
`app/build/outputs/apk/debug/app-debug.apk`

This project is source code; the current environment does not include an Android SDK/Gradle build toolchain, so the APK itself is not attached yet.
