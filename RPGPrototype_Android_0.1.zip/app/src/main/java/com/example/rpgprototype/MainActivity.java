package com.example.rpgprototype;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new GameView(this));
    }
}
class GameView extends View {
    Paint p=new Paint(3); Random rnd=new Random();
    float px=360, py=520, jx=0, jy=0; boolean joy=false, cave=false;
    int hp=100,gold=0,wood=0,stone=0,monster=30;
    ArrayList<Node> nodes=new ArrayList<>();
    RectF r=new RectF();

    GameView(Context c){super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD));
        for(int i=0;i<18;i++) nodes.add(new Node(35+rnd.nextFloat()*650,150+rnd.nextFloat()*680,0));
        for(int i=0;i<12;i++) nodes.add(new Node(35+rnd.nextFloat()*650,180+rnd.nextFloat()*650,1));
    }
    void txt(Canvas c,String s,float x,float y,float size){p.setTextSize(size);p.setColor(Color.WHITE);c.drawText(s,x,y,p);}
    @Override protected void onDraw(Canvas c){
        int w=getWidth(),h=getHeight();
        p.setColor(cave?Color.rgb(22,19,27):Color.rgb(39,75,42)); c.drawRect(0,0,w,h,p);
        if(!cave) for(Node n:nodes) if(n.alive){p.setColor(n.type==0?Color.rgb(35,125,62):Color.GRAY);c.drawCircle(n.x,n.y,n.type==0?27:18,p);}
        if(cave && monster>0){p.setColor(Color.rgb(140,43,226));c.drawCircle(360,300,30,p);}
        drawPlayer(c);
        p.setColor(0xCC111111);c.drawRoundRect(15,15,w-30,105,18,18,p);
        txt(c,"HP "+hp+"   Gold "+gold+"   Wood "+wood+"   Stone "+stone,30,50,22);
        txt(c,cave?"CAVE • Monster HP "+Math.max(0,monster):"FOREST • Farm resources",30,85,18);

        // joystick
        p.setColor(0x33FFFFFF);c.drawCircle(105,h-155,78,p);
        p.setColor(0x77FFFFFF);c.drawCircle(105+jx*78,h-155+jy*78,34,p);
        button(c,"ATTACK",w-180,h-205,160,70,0xFF9B2C2C);
        button(c,"FARM",w-180,h-115,160,70,0xFF8A6A24);
        button(c,cave?"EXIT CAVE":"ENTER CAVE",w-180,h-295,160,70,0xFF49315F);
    }
    void drawPlayer(Canvas c){
        p.setColor(Color.rgb(226,180,139));c.drawRect(px-17,py-54,px+17,py-24,p);
        p.setColor(Color.rgb(74,47,27));c.drawRect(px-19,py-58,px+19,py-50,p);
        p.setColor(Color.rgb(88,166,255));c.drawRect(px-18,py-24,px+18,py+12,p);
        p.setColor(Color.DKGRAY);c.drawRect(px-17,py+12,px-4,py+34,p);c.drawRect(px+4,py+12,px+17,py+34,p);
    }
    void button(Canvas c,String s,float x,float y,float ww,float hh,int color){
        p.setColor(color);c.drawRoundRect(x,y,x+ww,y+hh,18,18,p);p.setTextAlign(Paint.Align.CENTER);txt(c,s,x+ww/2,y+hh/2+8,17);p.setTextAlign(Paint.Align.LEFT);
    }
    boolean inside(float x,float y,float a,float b,float ww,float hh){return x>=a&&x<=a+ww&&y>=b&&y<=b+hh;}
    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        float x=e.getX(),y=e.getY(); int w=getWidth(),h=getHeight();
        if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){
            if(Math.hypot(x-105,y-(h-155))<110){joy=true; float vx=x-105,vy=y-(h-155),len=(float)Math.hypot(vx,vy); if(len>78){vx*=78/len;vy*=78/len;} jx=vx/78;jy=vy/78; invalidate(); return true;}
        }
        if(e.getAction()==MotionEvent.ACTION_UP){
            if(joy){joy=false;jx=jy=0;invalidate();}
            if(inside(x,y,w-180,h-295,160,70)){cave=!cave; monster=30; invalidate();return true;}
            if(inside(x,y,w-180,h-205,160,70)){if(cave&&monster>0&&Math.hypot(px-360,py-300)<150){monster-=10;if(monster<=0)gold+=25;}invalidate();return true;}
            if(inside(x,y,w-180,h-115,160,70)){farm();invalidate();return true;}
        }
        return true;
    }
    void farm(){for(Node n:nodes)if(n.alive&&Math.hypot(px-n.x,py-n.y)<60){n.alive=false;if(n.type==0)wood++;else stone++;return;}}
    @Override public boolean dispatchTouchEvent(MotionEvent e){return super.dispatchTouchEvent(e);}
    @Override public boolean onGenericMotionEvent(MotionEvent e){return super.onGenericMotionEvent(e);}
    @Override protected void onSizeChanged(int w,int h,int ow,int oh){px=w/2f;py=h*.42f;}
    @Override public boolean performClick(){super.performClick();return true;}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();post(new Runnable(){public void run(){invalidate();}});}
    class Node{float x,y;int type;boolean alive=true;Node(float a,float b,int t){x=a;y=b;type=t;}}
}
